create database SegurosPruebaDB;

-- =========================
-- CLIENTES
-- =========================
CREATE TABLE Clientes (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(150) NOT NULL,
    Identificacion NVARCHAR(50) NOT NULL,
    Correo NVARCHAR(150) NOT NULL,
    CONSTRAINT UQ_Cliente_Identificacion UNIQUE (Identificacion)
);

-- =========================
-- MARCAS
-- =========================
CREATE TABLE Marcas (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL UNIQUE
);

-- =========================
-- MODELOS
-- =========================
CREATE TABLE Modelos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    MarcaId INT NOT NULL,

    CONSTRAINT FK_Modelo_Marca
        FOREIGN KEY (MarcaId) REFERENCES Marcas(Id),

    CONSTRAINT UQ_Modelo_Marca UNIQUE (Nombre, MarcaId)
);

-- =========================
-- VEHICULOS
-- =========================
CREATE TABLE Vehiculos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Placa NVARCHAR(20) NOT NULL,
    ModeloId INT NOT NULL,
    Anio INT NOT NULL,
    ValorComercial DECIMAL(18,2) NOT NULL,

    CONSTRAINT UQ_Vehiculo_Placa UNIQUE (Placa),

    CONSTRAINT FK_Vehiculo_Modelo
        FOREIGN KEY (ModeloId) REFERENCES Modelos(Id)
);

-- =========================
-- COBERTURAS
-- =========================
CREATE TABLE Coberturas (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    MontoCobertura DECIMAL(18,2) NOT NULL,

    CONSTRAINT UQ_Cobertura_Nombre UNIQUE (Nombre)
);

-- =========================
-- POLIZAS
-- =========================
CREATE TABLE Polizas (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    NumeroPoliza NVARCHAR(50) NOT NULL,
    ClienteId INT NOT NULL,
    VehiculoId INT NOT NULL,
    FechaEmision DATETIME2 NOT NULL,
    SumaAsegurada DECIMAL(18,2) NOT NULL,
    PrimaTotal DECIMAL(18,2) NOT NULL,

    CONSTRAINT UQ_Poliza_Numero UNIQUE (NumeroPoliza),

    CONSTRAINT FK_Poliza_Cliente
        FOREIGN KEY (ClienteId) REFERENCES Clientes(Id),

    CONSTRAINT FK_Poliza_Vehiculo
        FOREIGN KEY (VehiculoId) REFERENCES Vehiculos(Id)
);

-- =========================
-- POLIZA COBERTURAS (N:N)
-- =========================
CREATE TABLE PolizaCoberturas (
    PolizaId INT NOT NULL,
    CoberturaId INT NOT NULL,

    PRIMARY KEY (PolizaId, CoberturaId),

    CONSTRAINT FK_PC_Poliza
        FOREIGN KEY (PolizaId) REFERENCES Polizas(Id),

    CONSTRAINT FK_PC_Cobertura
        FOREIGN KEY (CoberturaId) REFERENCES Coberturas(Id)
);