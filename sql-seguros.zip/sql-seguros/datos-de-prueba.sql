use SegurosPruebaDB

INSERT INTO Clientes (Nombre, Identificacion, Correo)
VALUES 
('Juan Pérez', '001-010101-0001A', 'juan@email.com'),
('María López', '002-020202-0002B', 'maria@email.com'),
('Carlos Ramírez', '003-030303-0003C', 'carlos@email.com');

INSERT INTO Marcas (Nombre)
VALUES 
('Toyota'),
('Honda'),
('Nissan');

INSERT INTO Modelos (Nombre, MarcaId)
VALUES
('Corolla', 1),
('Hilux', 1),
('Civic', 2),
('Sentra', 3);

INSERT INTO Vehiculos (Placa, ModeloId, Anio, ValorComercial)
VALUES
('M123456', 1, 2020, 15000),
('M654321', 2, 2022, 28000),
('M777888', 3, 2019, 13000),
('M999000', 4, 2021, 17000);

INSERT INTO Coberturas (Nombre, MontoCobertura)
VALUES
('especial', 1000000);

INSERT INTO Polizas 
(NumeroPoliza, ClienteId, VehiculoId, FechaEmision, SumaAsegurada, PrimaTotal)
VALUES
('POL-0001', 1, 1, GETDATE(), 15000, 750),
('POL-0002', 2, 2, GETDATE(), 28000, 1400);

-- Poliza 1
INSERT INTO PolizaCoberturas (PolizaId, CoberturaId)
VALUES
(1, 1),
(1, 2),
(1, 3);

-- Poliza 2
INSERT INTO PolizaCoberturas (PolizaId, CoberturaId)
VALUES
(2, 1),
(2, 4);